#include <stdio.h>



void up_fill(int *array, char *string)
{
	int i = 0;

	while (string[i] != '\0')
	{
		array[(int)string[i]]++;
		i++;
	}
}




#define a_size 300

int main(int argc, char *argv[])
{
	int i = 1;
	int array[a_size] = {0};

	for (i = 1; i < argc; i++)
	{
		up_fill(&array[0], argv[i]);
	}
	for (i = 0; i < a_size; i++)
	{
		if (i != '"' && array[i] > 0)
		{
			printf("%c:%d\n", i, array[i]);
		}
	}

	return (0);
}
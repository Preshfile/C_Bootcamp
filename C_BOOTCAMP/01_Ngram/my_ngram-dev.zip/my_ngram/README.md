# Welcome to My Ngram
Welcome to My Ngram Project.
An n_gram is the colletion of the number of occurence of text or letters.
This the program to be builts counts how many times a letter occured in a collection.

## Task
The challenge is to write a program that counts the number of occurences per character in a collection.
Conditions to be met in solving this problem includes:
1. Must have just two files - a makefile and a .c file.
2. Not more than one .c file is accepted.
3. The Makefile must follow certain stipulated structure: it must have a clean & fclean,
4. and must be compiled with the flags -Wall -Wextra -Werror.


## Description
Solution Description
First, all elements of the strings are compared using for loop for(i=0;s[i];i++).
Secondly, If it matches with the element of the string then increament is made to the count.
Thirdly, The function returns the count value  and then prints the count value.

## Installation
The program can be run on the local machine with the necessary compiler for running a C program installed.
Make my_ngram.C
Make clean  and 
make fclean
were some special command used to build the executable files 
including deleting objects and executable files from an editor


## Usage
USES OF THE N GRAM
this program is extensively used in text mining and natural language processing tasks.
N-gram can be used for a variety of different tasks ranging from 
developing not just unigram models but also bigram and trigram models to developing features 
for supervised Machine Learning models such as SVMs, MaxEnt models, Naive Bayes, etc.

### The Core Team
This Program was written by a group of two persons:
1. Precious Oranye
2. Martin Obiarandu Agoha

Both are software engineering students undergoing upskilling at Qwasar, Silicon valley.
The Project is one of the mandatory projects to be completed to complete Qwasar upskilling programme.


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px'></span>
